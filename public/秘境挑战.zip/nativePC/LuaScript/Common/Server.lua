local json = require "nativePC/LuaScript/Common/json"
--[[
    ApiServer处理程序
]]
local ServerFunction = {}
--链接服务器
function ServerFunction.LinkServer(serve)
    if not System_Chronoscope_CheckPresenceChronoscope('WSS_Reconnect') then
        if not Lua_WS_GetLinkState() then
            Lua_WS_LinkWSServer(serve)
            System_Chronoscope_AddChronoscope(3,'WSS_Reconnect')
        end
    end
end
--获取、设置UUID
function ServerFunction.ServerUUID()
    local UUID = Lua_Variable_ReadGlobalStringVariable('ServerUUID')
    if UUID == '' then
        UUID = System_GetUUID()
        Lua_Variable_SaveGlobalStringVariable('ServerUUID',UUID)
    end
    return UUID
end
--发送服务器指令
--[[
    @command 指令
    @data 数据
]]
function ServerFunction.SendCommand(command,data)
    local name,hr,mr = Game_Player_GetPlayerRoleInfo()
    local SendData = json.encode({
        Command = command,
        Data = data,
        User = {
            Name = name,
            UUID = ServerFunction.ServerUUID(),
            Team = 'SecretTerritoryChallenge',
            SteamId = Game_World_SteamId(),
        },
    })
    Lua_WS_SendMessage(SendData)
end
--获取服务器指令
function ServerFunction.ListenServer()
    local WWSData = Lua_WS_GetMessage()
    if WWSData ~= '' then
        local ServerData = json.decode(WWSData)
        if ServerData.User == nil or (ServerData.User.Team == 'SecretTerritoryChallenge' and ServerData.User.UUID ~= ServerFunction.ServerUUID())
        then
            return ServerData
        end
    end
end
function ServerFunction.ExecuteCommand()
    local ServerCommand = ServerFunction.ListenServer()
    if ServerCommand ~= nil then
        if ServerCommand.Command == 'Login' then
            ServerFunction.LoginTips(ServerCommand.Data)
        end
        if ServerCommand.Command == 'Message' then
            ServerFunction.Message(ServerCommand.Data)
        end
    end
end
--[[
    游戏内功能
]]
--发送登陆提示
function ServerFunction.LoginTips(ServerData)
    local CaimoguUser = 'Steam玩家 '..ServerData.Name
    System_Message_ShowMessage('欢迎'..CaimoguUser..'\n集会区域'..ServerData.Assembly)
end
--发送聊天信息
function ServerFunction.Message(ServerData)
    System_Message_ShowMessage(ServerData.Name..':\n'..ServerData.Message)
end
return ServerFunction